
package com.mycompany.question1;

public class Dog extends Animal {
        public void makeSound() {
        System.out.println("Woof Woof");
    }
}
