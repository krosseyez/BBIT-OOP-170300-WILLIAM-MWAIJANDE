
package com.mycompany.question1;

public class Animal {
    public void makeSound() {
        System.out.println("Some animal sound");
    }
}
