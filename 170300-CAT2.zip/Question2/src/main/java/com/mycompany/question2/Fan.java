package com.mycompany.question2;

public class Fan extends Appliance {
    void turnOn() {
        System.out.println("Fan is running...");
    }
}
