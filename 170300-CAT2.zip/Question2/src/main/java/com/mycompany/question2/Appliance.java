package com.mycompany.question2;

abstract class Appliance {
 abstract void turnOn();   
}
