package com.mycompany.question2;

public class Tv extends Appliance {
    void turnOn() {
        System.out.println("TV is on...");
    }
}
